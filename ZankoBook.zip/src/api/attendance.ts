import api from '../lib/axios'
import type {
  AttendanceRecord,
  AttendanceWeek,
  CourseStudent,
  CreateAttendanceWeekPayload,
  CreateAttendanceWeekResponse,
  GetAttendanceRecordsResponse,
  GetAttendanceWeeksResponse,
  GetCourseStudentsResponse,
  RecordAttendanceResponse,
  SaveAttendancePayload,
} from '../types/attendance'

const wait = (milliseconds = 350) =>
  new Promise((resolve) => setTimeout(resolve, milliseconds))

const fakeStudents: CourseStudent[] = [
  { id: 1, user: { id: 101, name: 'Ava Hassan' } },
  { id: 2, user: { id: 102, name: 'Baran Ahmed' } },
  { id: 3, user: { id: 103, name: 'Dilan Karim' } },
  { id: 4, user: { id: 104, name: 'Hana Mohammed' } },
  { id: 5, user: { id: 105, name: 'Omar Ali' } },
]

let fakeWeeks: AttendanceWeek[] = [
  {
    id: 1,
    course_id: 1,
    title: 'Week 1 — Introduction',
    session_date: '2026-07-06',
    start_at: '2026-07-06 09:00:00',
    end_at: '2026-07-06 10:30:00',
  },
]

const fakeRecords = new Map<number, AttendanceRecord[]>()

// -----------------------------------------------------------------------------
// REAL API METHODS
// Uncomment this block and comment out the fake methods below when the backend
// is ready. The exported function names stay exactly the same.
// -----------------------------------------------------------------------------
/*
export async function createAttendanceWeek(
  payload: CreateAttendanceWeekPayload,
): Promise<AttendanceWeek> {
  const response = await api.post<CreateAttendanceWeekResponse>(
    '/api/moodle/attendance-sessions',
    payload,
  )
  const { success, message, data } = response.data
  if (!success) throw new Error(message)
  return data
}

export async function getCourseStudents(courseId: number): Promise<CourseStudent[]> {
  const response = await api.get<GetCourseStudentsResponse>(
    `/api/courses/${courseId}/students`,
  )
  const { success, message, data } = response.data
  if (!success) throw new Error(message)
  return data.data
}

export async function getAttendanceWeeks(courseId: number): Promise<AttendanceWeek[]> {
  const response = await api.get<GetAttendanceWeeksResponse>(
    '/api/moodle/attendance-sessions',
    { params: { course_id: courseId } },
  )
  const { success, message, data } = response.data
  if (!success) throw new Error(message)
  return data
}

export async function getAttendanceRecords(weekId: number): Promise<AttendanceRecord[]> {
  const response = await api.get<GetAttendanceRecordsResponse>(
    `/api/moodle/attendance-sessions/${weekId}/attendance`,
  )
  const { success, message, data } = response.data
  if (!success) throw new Error(message)
  return data
}

export async function submitAttendanceRecords(
  payload: SaveAttendancePayload,
  weekId: number,
): Promise<AttendanceRecord[]> {
  const response = await api.post<RecordAttendanceResponse>(
    `/api/moodle/attendance-sessions/${weekId}/attendance`,
    payload,
  )
  const { success, message, data } = response.data
  if (!success) throw new Error(message)
  return data
}
*/

// -----------------------------------------------------------------------------
// FAKE METHODS FOR TESTING
// Comment out this block when enabling the real methods above.
// -----------------------------------------------------------------------------
export async function createAttendanceWeek(
  payload: CreateAttendanceWeekPayload,
): Promise<AttendanceWeek> {
  await wait()
  const week: AttendanceWeek = {
    id: Date.now(),
    ...payload,
  }
  fakeWeeks = [week, ...fakeWeeks]
  return week
}

export async function getCourseStudents(_courseId: number): Promise<CourseStudent[]> {
  await wait()
  return fakeStudents
}

export async function getAttendanceWeeks(courseId: number): Promise<AttendanceWeek[]> {
  await wait()
  return fakeWeeks.filter((week) => week.course_id === courseId || week.course_id === 1)
}

export async function getAttendanceRecords(weekId: number): Promise<AttendanceRecord[]> {
  await wait()
  return fakeRecords.get(weekId) ?? []
}

export async function submitAttendanceRecords(
  payload: SaveAttendancePayload,
  weekId: number,
): Promise<AttendanceRecord[]> {
  await wait()
  const records = payload.records.map((record) => ({ ...record }))
  fakeRecords.set(weekId, records)
  return records
}

void api
