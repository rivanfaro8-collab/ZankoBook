import { Ionicons } from '@expo/vector-icons'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useEffect, useMemo, useState } from 'react'
import {
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from 'react-native'

import { createAttendanceWeek } from '../../src/api/attendance'
import { useAppTheme } from '../../src/store/themeStore'
import type { AttendanceWeek } from '../../src/types/attendance'
import ThemedText from '../ThemedText'

const today = () => {
  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

const validDate = (value: string) => /^\d{4}-\d{2}-\d{2}$/.test(value)
const validTime = (value: string) => /^([01]\d|2[0-3]):[0-5]\d$/.test(value)

type Props = {
  visible: boolean
  courseId: number
  onClose: () => void
  onCreated: (week: AttendanceWeek) => void
}

export default function AddAttendanceSessionModal({
  visible,
  courseId,
  onClose,
  onCreated,
}: Props) {
  const theme = useAppTheme()
  const queryClient = useQueryClient()
  const [title, setTitle] = useState('')
  const [sessionDate, setSessionDate] = useState(today())
  const [startTime, setStartTime] = useState('')
  const [endTime, setEndTime] = useState('')

  useEffect(() => {
    if (!visible) return
    setTitle('')
    setSessionDate(today())
    setStartTime('')
    setEndTime('')
  }, [visible])

  const timeOrderValid = validTime(startTime) && validTime(endTime) && endTime > startTime
  const formValid = useMemo(
    () =>
      title.trim().length > 0 &&
      validDate(sessionDate) &&
      timeOrderValid,
    [endTime, sessionDate, startTime, timeOrderValid, title],
  )

  const mutation = useMutation({
    mutationFn: createAttendanceWeek,
    onSuccess: (week) => {
      queryClient.invalidateQueries({ queryKey: ['attendance-weeks', courseId] })
      onCreated(week)
      onClose()
    },
  })

  const submit = () => {
    if (!formValid || mutation.isPending) return
    mutation.mutate({
      course_id: courseId,
      title: title.trim(),
      session_date: sessionDate,
      start_at: `${sessionDate} ${startTime}:00`,
      end_at: `${sessionDate} ${endTime}:00`,
    })
  }

  const inputStyle = [
    styles.input,
    {
      color: theme.title,
      backgroundColor: theme.uiBackground,
      borderColor: theme.border,
    },
  ]

  return (
    <Modal visible={visible} transparent animationType='fade' onRequestClose={onClose}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.overlay}
      >
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View
          style={[
            styles.card,
            { backgroundColor: theme.background, borderColor: theme.border },
          ]}
        >
          <View style={styles.header}>
            <ThemedText title style={styles.heading}>
              Add attendance session
            </ThemedText>
            <Pressable
              onPress={onClose}
              style={[styles.closeButton, { backgroundColor: theme.uiBackground }]}
            >
              <Ionicons name='close' size={21} color={theme.text} />
            </Pressable>
          </View>

          <ScrollView keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
            <ThemedText title style={styles.label}>Session title</ThemedText>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder='e.g. Week 4 — Trees'
              placeholderTextColor={theme.text}
              style={inputStyle}
            />

            <View style={styles.labelRow}>
              <ThemedText title style={styles.label}>Session date</ThemedText>
              <Pressable onPress={() => setSessionDate(today())}>
                <ThemedText title style={{ color: theme.primary, fontSize: 13 }}>
                  Today
                </ThemedText>
              </Pressable>
            </View>
            <TextInput
              value={sessionDate}
              onChangeText={setSessionDate}
              placeholder='YYYY-MM-DD'
              placeholderTextColor={theme.text}
              keyboardType='numbers-and-punctuation'
              style={inputStyle}
            />

            <View style={styles.timeRow}>
              <View style={styles.timeField}>
                <ThemedText title style={styles.label}>Start time</ThemedText>
                <TextInput
                  value={startTime}
                  onChangeText={setStartTime}
                  placeholder='09:00'
                  placeholderTextColor={theme.text}
                  keyboardType='numbers-and-punctuation'
                  style={inputStyle}
                />
              </View>
              <View style={styles.timeField}>
                <ThemedText title style={styles.label}>End time</ThemedText>
                <TextInput
                  value={endTime}
                  onChangeText={setEndTime}
                  placeholder='10:30'
                  placeholderTextColor={theme.text}
                  keyboardType='numbers-and-punctuation'
                  style={inputStyle}
                />
              </View>
            </View>

            {startTime.length > 0 && endTime.length > 0 && !timeOrderValid ? (
              <ThemedText style={[styles.error, { color: theme.danger }]}>End time must be after start time.</ThemedText>
            ) : null}
            {mutation.error ? (
              <ThemedText style={[styles.error, { color: theme.danger }]}>
                {(mutation.error as Error).message}
              </ThemedText>
            ) : null}

            <Pressable
              disabled={!formValid || mutation.isPending}
              onPress={submit}
              style={({ pressed }) => [
                styles.submit,
                {
                  backgroundColor: theme.primary,
                  opacity: !formValid || mutation.isPending ? 0.45 : pressed ? 0.78 : 1,
                },
              ]}
            >
              <ThemedText title style={styles.submitText}>
                {mutation.isPending ? 'Adding…' : 'Add'}
              </ThemedText>
            </Pressable>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  )
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    paddingHorizontal: 18,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.52)',
  },
  card: {
    maxHeight: '88%',
    borderWidth: 1,
    borderRadius: 22,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.22,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  heading: { fontSize: 20, fontWeight: '800' },
  closeButton: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: { fontSize: 14, fontWeight: '700', marginBottom: 7 },
  labelRow: {
    marginTop: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 14,
    fontSize: 15,
  },
  timeRow: { flexDirection: 'row', gap: 12, marginTop: 16 },
  timeField: { flex: 1 },
  error: { marginTop: 10, fontSize: 12, textAlign: 'center' },
  submit: {
    height: 50,
    borderRadius: 14,
    marginTop: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitText: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },
})
