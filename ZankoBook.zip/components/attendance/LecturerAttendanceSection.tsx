import { Ionicons } from '@expo/vector-icons'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useMemo, useState } from 'react'
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  View,
} from 'react-native'

import {
  getAttendanceRecords,
  getAttendanceWeeks,
  getCourseStudents,
  submitAttendanceRecords,
} from '../../src/api/attendance'
import { useAppTheme } from '../../src/store/themeStore'
import type {
  AttendanceStatus,
  AttendanceWeek,
} from '../../src/types/attendance'
import ThemedText from '../ThemedText'
import AddAttendanceSessionModal from './AddAttendanceSessionModal'
import StudentAttendanceRow from './StudentAttendanceRow'

type Props = { courseId: number }

type AttendanceMap = Record<number, AttendanceStatus>

const formatTime = (value: string) => {
  const match = value.match(/(\d{2}:\d{2})/)
  return match?.[1] ?? value
}

export default function LecturerAttendanceSection({ courseId }: Props) {
  const theme = useAppTheme()
  const queryClient = useQueryClient()
  const [modalVisible, setModalVisible] = useState(false)
  const [selectedWeekId, setSelectedWeekId] = useState<number | null>(null)
  const [attendance, setAttendance] = useState<AttendanceMap>({})

  const weeksQuery = useQuery({
    queryKey: ['attendance-weeks', courseId],
    queryFn: () => getAttendanceWeeks(courseId),
  })

  useEffect(() => {
    if (selectedWeekId !== null) return
    const firstWeek = weeksQuery.data?.[0]
    if (firstWeek) setSelectedWeekId(firstWeek.id)
  }, [selectedWeekId, weeksQuery.data])

  const studentsQuery = useQuery({
    queryKey: ['course-students', courseId],
    queryFn: () => getCourseStudents(courseId),
  })

  const recordsQuery = useQuery({
    queryKey: ['attendance-records', selectedWeekId],
    queryFn: () => getAttendanceRecords(selectedWeekId as number),
    enabled: selectedWeekId !== null,
  })

  useEffect(() => {
    if (!selectedWeekId || !recordsQuery.data) return
    const next: AttendanceMap = {}
    recordsQuery.data.forEach((record) => {
      next[record.student_id] = record.status
    })
    setAttendance(next)
  }, [recordsQuery.data, selectedWeekId])

  const selectedWeek = useMemo(
    () => weeksQuery.data?.find((week) => week.id === selectedWeekId),
    [selectedWeekId, weeksQuery.data],
  )

  const saveMutation = useMutation({
    mutationFn: () =>
      submitAttendanceRecords(
        {
          records: Object.entries(attendance).map(([studentId, status]) => ({
            student_id: Number(studentId),
            status,
          })),
        },
        selectedWeekId as number,
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['attendance-records', selectedWeekId] })
      Alert.alert('Saved', 'Attendance records were saved successfully.')
    },
  })

  const selectWeek = (week: AttendanceWeek) => {
    setSelectedWeekId(week.id)
    setAttendance({})
  }

  const setStatus = (studentId: number, status: AttendanceStatus) => {
    setAttendance((current) => ({ ...current, [studentId]: status }))
  }

  const saveDisabled =
    selectedWeekId === null ||
    Object.keys(attendance).length === 0 ||
    saveMutation.isPending

  if (weeksQuery.isLoading || studentsQuery.isLoading) {
    return <ActivityIndicator style={styles.loader} size='large' color={theme.primary} />
  }

  if (weeksQuery.error || studentsQuery.error) {
    return (
      <View style={styles.center}>
        <Ionicons name='alert-circle-outline' size={42} color={theme.danger} />
        <ThemedText title style={styles.centerTitle}>Could not load attendance</ThemedText>
        <Pressable
          onPress={() => {
            weeksQuery.refetch()
            studentsQuery.refetch()
          }}
          style={[styles.retry, { backgroundColor: theme.primary }]}
        >
          <ThemedText title style={styles.whiteText}>Try again</ThemedText>
        </Pressable>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.topRow}>
        <View>
          <ThemedText title style={styles.heading}>Attendance sessions</ThemedText>
          <ThemedText style={styles.subheading}>Choose a session, then mark each student.</ThemedText>
        </View>
        <Pressable
          onPress={() => setModalVisible(true)}
          style={({ pressed }) => [
            styles.addButton,
            { backgroundColor: theme.primary, opacity: pressed ? 0.76 : 1 },
          ]}
        >
          <Ionicons name='add' size={20} color='#FFFFFF' />
          <ThemedText title style={styles.whiteText}>New</ThemedText>
        </Pressable>
      </View>

      <FlatList
        horizontal
        data={weeksQuery.data ?? []}
        keyExtractor={(item) => String(item.id)}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.weekList}
        ListEmptyComponent={
          <View style={[styles.emptyWeek, { borderColor: theme.border }]}> 
            <ThemedText>No sessions yet. Create the first one.</ThemedText>
          </View>
        }
        renderItem={({ item }) => {
          const active = item.id === selectedWeekId
          return (
            <Pressable
              onPress={() => selectWeek(item)}
              style={({ pressed }) => [
                styles.weekCard,
                {
                  backgroundColor: active ? theme.primary : theme.uiBackground,
                  borderColor: active ? theme.primary : theme.border,
                  opacity: pressed ? 0.75 : 1,
                },
              ]}
            >
              <ThemedText title style={{ color: active ? '#FFFFFF' : theme.title, fontSize: 14 }} numberOfLines={1}>
                {item.title}
              </ThemedText>
              <ThemedText style={{ color: active ? '#FFFFFF' : theme.text, fontSize: 12 }}>
                {item.session_date}
              </ThemedText>
              <ThemedText style={{ color: active ? '#FFFFFF' : theme.text, fontSize: 11 }}>
                {formatTime(item.start_at)}–{formatTime(item.end_at)}
              </ThemedText>
            </Pressable>
          )
        }}
      />

      {selectedWeek ? (
        <View style={[styles.rosterCard, { backgroundColor: theme.background, borderColor: theme.border }]}>
          <View style={[styles.rosterHeader, { borderBottomColor: theme.border }]}> 
            <View style={{ flex: 1 }}>
              <ThemedText title style={styles.rosterTitle}>{selectedWeek.title}</ThemedText>
              <ThemedText style={styles.rosterMeta}>{studentsQuery.data?.length ?? 0} students</ThemedText>
            </View>
            <View style={styles.legend}>
              <ThemedText style={styles.legendText}>P</ThemedText>
              <ThemedText style={styles.legendText}>A</ThemedText>
              <ThemedText style={styles.legendText}>L</ThemedText>
              <ThemedText style={styles.legendText}>E</ThemedText>
            </View>
          </View>

          {recordsQuery.isLoading ? (
            <ActivityIndicator style={styles.recordsLoader} color={theme.primary} />
          ) : (
            <FlatList
              data={studentsQuery.data ?? []}
              keyExtractor={(item) => String(item.id)}
              renderItem={({ item }) => (
                <StudentAttendanceRow
                  student={item}
                  status={attendance[item.id]}
                  disabled={saveMutation.isPending}
                  onStatusChange={setStatus}
                />
              )}
              refreshControl={
                <RefreshControl
                  refreshing={recordsQuery.isRefetching}
                  onRefresh={() => recordsQuery.refetch()}
                  tintColor={theme.primary}
                />
              }
              ListEmptyComponent={
                <View style={styles.center}><ThemedText>No students found.</ThemedText></View>
              }
            />
          )}

          <Pressable
            disabled={saveDisabled}
            onPress={() => saveMutation.mutate()}
            style={({ pressed }) => [
              styles.saveButton,
              {
                backgroundColor: theme.primary,
                opacity: saveDisabled ? 0.42 : pressed ? 0.76 : 1,
              },
            ]}
          >
            <Ionicons name='save-outline' size={20} color='#FFFFFF' />
            <ThemedText title style={styles.whiteText}>
              {saveMutation.isPending ? 'Saving…' : 'Save attendance'}
            </ThemedText>
          </Pressable>
          {saveMutation.error ? (
            <ThemedText style={[styles.mutationError, { color: theme.danger }]}>
              {(saveMutation.error as Error).message}
            </ThemedText>
          ) : null}
        </View>
      ) : null}

      <AddAttendanceSessionModal
        visible={modalVisible}
        courseId={courseId}
        onClose={() => setModalVisible(false)}
        onCreated={(week) => setSelectedWeekId(week.id)}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingTop: 16 },
  loader: { flex: 1 },
  center: { minHeight: 150, alignItems: 'center', justifyContent: 'center', padding: 20 },
  centerTitle: { marginTop: 10, fontSize: 17 },
  retry: { marginTop: 14, paddingHorizontal: 20, paddingVertical: 11, borderRadius: 12 },
  topRow: { paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  heading: { fontSize: 19, fontWeight: '800' },
  subheading: { marginTop: 3, fontSize: 12 },
  addButton: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 13, height: 42, borderRadius: 13 },
  whiteText: { color: '#FFFFFF', fontWeight: '800' },
  weekList: { paddingHorizontal: 16, paddingVertical: 14, gap: 10 },
  weekCard: { width: 174, minHeight: 82, borderRadius: 15, borderWidth: 1, padding: 12, justifyContent: 'space-between' },
  emptyWeek: { borderWidth: 1, borderStyle: 'dashed', borderRadius: 14, padding: 18 },
  rosterCard: { flex: 1, marginHorizontal: 16, marginBottom: 14, borderWidth: 1, borderRadius: 18, overflow: 'hidden' },
  rosterHeader: { paddingHorizontal: 16, paddingVertical: 13, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center' },
  rosterTitle: { fontSize: 16, fontWeight: '800' },
  rosterMeta: { marginTop: 2, fontSize: 12 },
  legend: { flexDirection: 'row', gap: 20, paddingRight: 5 },
  legendText: { width: 16, textAlign: 'center', fontSize: 11, fontWeight: '700' },
  recordsLoader: { flex: 1 },
  saveButton: { minHeight: 50, margin: 12, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  mutationError: { textAlign: 'center', marginHorizontal: 12, marginBottom: 10, fontSize: 12 },
})
