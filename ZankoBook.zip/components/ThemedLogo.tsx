import { useEventListener } from 'expo'
import { useVideoPlayer, VideoView, type VideoViewProps } from 'expo-video'

const LogoVideo = require('../assets/img/zankobook3.mp4')

type ThemedLogoProps = Omit<VideoViewProps, 'player'>

export default function ThemedLogo({ style, ...props }: ThemedLogoProps) {
  const player = useVideoPlayer(LogoVideo, (videoPlayer) => {
    videoPlayer.loop = false
    videoPlayer.muted = true
    videoPlayer.play()
  })

  useEventListener(player, 'playToEnd', () => {
    player.pause()
    player.currentTime = Math.max(0, player.duration - 0.01)
  })

  return (
    <VideoView
      player={player}
      style={style}
      contentFit="contain"
      nativeControls={false}
      {...props}
    />
  )
}
