import AcademicRequestsScreen from '../../../components/requests/AcademicRequestsScreen'

export default function LecturerRequests() {
  return <AcademicRequestsScreen />
}
